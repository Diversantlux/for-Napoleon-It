<template>
  <div class="info">
    <h1>{{ msg }}</h1>
    <p>Просто текст</p>
    
  </div>
</template>


<script>
export default {
props: ['msg'],
name: 'InfoComponent'
  
}
</script>

<style scoped>
.info {
    background-color: rgb(212, 212, 212);
}
</style>
