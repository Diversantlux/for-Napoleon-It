




<template lang="pug">
    ul
        li(v-for="item in InnerComponent")
</template>

<script>
export default {
   name:"InnerComponent",
   props:{
 InnerComponent: Array
   } 
}
</script>