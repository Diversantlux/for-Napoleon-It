<template>
  <div class="hello">
    <h1>{{msg}}</h1>
    <p>
      {{helloArray}}
      <a href="https://cli.vuejs.org" target="_blank" rel="noopener">vue-cli documentation</a>.
    </p>
   
    <ul>
      <li v-for="item in essential" :key="item.link"><a :href="item.link" target="_blank" rel="noopener">{{item.name}}</a></li>
    </ul>
    
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data(){
    return{
      helloArray: ['hello', 'world'],
      essential: [{link: 'https://vuejs.org', name:'Core Docs'},
      {link: 'https://forum.vuejs.org', name:'Forum'}]
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
