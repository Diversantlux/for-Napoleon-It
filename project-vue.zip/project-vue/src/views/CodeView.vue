<template>
  <div class="info">
    <p>efwefwe</p>
    <img alt="Vue logo" src="../assets/logo.png">
  </div>
  </template>