<template lang="pug">
  
</template> 


<script>
export default {
  name:"About",
  data(){
    return{
      myJson:[],
      inputFilter:''
    }
  },
  computed:  {
    filterredJson(){
      return this.myJson.filter(element => element.title.includes(this.inputFilter))
    }
  }
}
</script>