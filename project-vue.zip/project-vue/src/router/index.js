import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import HelloComponent from '../components/HelloComponent.vue'
import InfoView from '../views/InfoView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/Helloworld',
    name: 'Helloworld',
    component: HelloComponent
  },
  {
    path: '/Info',
    name: 'InfoView',
    component: InfoView
    
  },
  {
    path: '/Code',
    name: 'CodeView'
  },
  {
    path: '/about',
    name: 'About',

    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode:'history',
  routes
})

export default router
