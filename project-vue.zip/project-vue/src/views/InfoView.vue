<template>
  <div class="info">
    <p>efwefwe</p>
    <img alt="Vue logo" src="../assets/logo.png">
    <InfoComponent msg="ggwp"/>
    <HelloComponent/>
  </div>
</template>

<script>
// @ is an alias to /src
import InfoComponent from '@/components/InfoComponent'


export default {
  name: 'InfoView', 
  components: {
    InfoComponent
    
  }
}
</script>